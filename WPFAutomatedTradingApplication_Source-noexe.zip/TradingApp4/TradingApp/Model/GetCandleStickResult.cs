﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradingApp.DataAccess;

namespace TradingApp.Model
{
    public class GetCandleStickResult
    {
        public GetCandleStickResultType ResultType { get; set; }

        public List<string> Errors { get; set; }

        public Exception Exception { get; set; }
        
        public CandleStick CandleStick { get; set; }

        public long Last { get; set; }
    }

    public enum GetCandleStickResultType
    { 
        success,
        error,
        exception
    }
}
