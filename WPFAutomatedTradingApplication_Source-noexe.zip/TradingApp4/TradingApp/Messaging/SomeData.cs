﻿namespace TradingApp.Messaging
{
    /// <summary>
    /// Class that holds some data that a ViewModel wants to pass to another ViewModel
    /// </summary>
    public class SomeData
    {
        public string Text { get; set; }
    }
}
