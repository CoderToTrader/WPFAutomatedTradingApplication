﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradingApp.ConnectorService;
using TradingApp.DataAccess;
using TradingApp.Model;

namespace TradingApp.Messaging
{
    public class PriceData
    {
        public PriceData(CandleStick candleStick, PricePoint wmaPoint,bool live)
        {
            CandleStick = candleStick;
            WmaPoint = wmaPoint;
            Live = live;
        }
        
        public CandleStick CandleStick { get; set; }
        public PricePoint WmaPoint { get; set; }
        public bool Live { get; set; }
    }
}
