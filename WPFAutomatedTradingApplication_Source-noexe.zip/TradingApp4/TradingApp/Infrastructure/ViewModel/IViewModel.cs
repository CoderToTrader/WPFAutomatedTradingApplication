﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.Infrastructure
{
    /// <summary>
    /// Contract for all ViewModels
    /// </summary>
    public interface IViewModel
    {
        //Empty for now
    }
}
