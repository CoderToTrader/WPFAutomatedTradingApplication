﻿using TradingApp.Infrastructure;
using TradingApp.ViewModel;

namespace TradingApp.View
{
    /// <summary>
    /// Interaction logic for GraphView.xaml
    /// </summary>
    public partial class GraphView
    {
        public GraphView()
        {
            this.InitializeComponent();
        }
    }
}
