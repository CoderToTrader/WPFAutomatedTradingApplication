﻿using TradingApp.Infrastructure;
using TradingApp.ViewModel;

namespace TradingApp.View
{
	/// <summary>
	/// Interaction logic for ControlView.xaml
	/// </summary>
	public partial class ControlView 
	{
		public ControlView()
		{
			this.InitializeComponent();
			
		}
	}
}