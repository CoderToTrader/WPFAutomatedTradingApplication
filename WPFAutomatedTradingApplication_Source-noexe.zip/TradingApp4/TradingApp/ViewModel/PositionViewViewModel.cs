﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TradingApp.DataAccess;
using TradingApp.Infrastructure;
using TradingApp.Messaging;

namespace TradingApp.ViewModel
{
    public class PositionViewViewModel:ViewModelBase
    {
        public PositionViewViewModel()
        {
            Mediator.Register(this);
        }

        decimal ongoingContracts;
        public decimal OngoingContracts
        {
            get 
            {
                return ongoingContracts;
            }
            set 
            {
                ongoingContracts = value;
                base.RaisePropertyChanged(() => this.OngoingContracts);
            }
        }

        Order openOrder;
        public Order OpenOrder
        {
            get
            {
                return openOrder;
            }
            set
            {
                openOrder = value;
                //notify view
                base.RaisePropertyChanged(() => this.OpenOrder);
            }
        }

        Order emergencyExitOrder;
        public Order EmergencyExitOrder
        {
            get
            {
                return emergencyExitOrder;
            }
            set
            {
                emergencyExitOrder = value;
                //notify view
                base.RaisePropertyChanged(() => this.EmergencyExitOrder);
            }
        }

        [MediatorMessageSink(MediatorMessages.UpdateOngoingContracts, ParameterType = typeof(decimal))]
        public void UpdateOngoingContracts(decimal ongoingContractsIncrement)
        {

              OngoingContracts += ongoingContractsIncrement;
            
        }

        [MediatorMessageSink(MediatorMessages.UpdateOrder, ParameterType = typeof(Order))]
        public void UpdateOpenOrder(Order order)
        {

            OpenOrder = order;

        }

        [MediatorMessageSink(MediatorMessages.UpdateEmergencyOrder, ParameterType = typeof(Order))]
        public void UpdateEmergencyOrder(Order order)
        {

            EmergencyExitOrder = order;

        }
    }
}
