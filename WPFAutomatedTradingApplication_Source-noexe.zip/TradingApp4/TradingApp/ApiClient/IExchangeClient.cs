﻿using System;
namespace TradingApp.ApiClient
{
    /// <summary>
    /// Defines the functionality that exchange classes have to implement to be pluggable 
    /// </summary>
    public interface IExchangeClient
    {        
        System.Collections.Generic.IList<TradingApp.ConnectorService.PricePoint> CatchUp();
        System.Collections.Generic.IList<TradingApp.ConnectorService.PricePoint> GetPricePoints(DateTimeOffset start, DateTimeOffset? end);
        TradingApp.Model.GetCandleStickResult GetCandleStick(long last);
        TradingApp.Model.PlaceOrderResult PlaceOrder(TradingApp.DataAccess.Order order, bool wait);
        TradingApp.Model.CancelOrderResult CancelOrder(TradingApp.DataAccess.Order order);
        void HandleErrors(System.Collections.Generic.List<string> errors);
        void HandleException(Exception exception);
    }
}
