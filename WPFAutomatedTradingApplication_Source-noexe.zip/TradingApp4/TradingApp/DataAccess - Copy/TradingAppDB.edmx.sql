
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 06/26/2014 21:05:21
-- Generated from EDMX file: C:\Users\arriv_000\Desktop\TradingApp3\TradingApp\DataAccess\TradingAppDB.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [TradingAppDB];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[FK_Confirmation_CandleStick]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Confirmation] DROP CONSTRAINT [FK_Confirmation_CandleStick];
GO
IF OBJECT_ID(N'[dbo].[FK_Confirmation_Setup]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Confirmation] DROP CONSTRAINT [FK_Confirmation_Setup];
GO
IF OBJECT_ID(N'[dbo].[FK_Order_CandleStick]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Order] DROP CONSTRAINT [FK_Order_CandleStick];
GO
IF OBJECT_ID(N'[dbo].[FK_Order_Confirmation]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Order] DROP CONSTRAINT [FK_Order_Confirmation];
GO
IF OBJECT_ID(N'[dbo].[FK_Setup_CandleStick]', 'F') IS NOT NULL
    ALTER TABLE [dbo].[Setup] DROP CONSTRAINT [FK_Setup_CandleStick];
GO

-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[CandleStick]', 'U') IS NOT NULL
    DROP TABLE [dbo].[CandleStick];
GO
IF OBJECT_ID(N'[dbo].[Confirmation]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Confirmation];
GO
IF OBJECT_ID(N'[dbo].[Order]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Order];
GO
IF OBJECT_ID(N'[dbo].[Setup]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Setup];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'CandleSticks'
CREATE TABLE [dbo].[CandleSticks] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [OpenTime] datetimeoffset  NOT NULL,
    [CloseTime] datetimeoffset  NOT NULL,
    [Open] decimal(18,4)  NOT NULL,
    [High] decimal(18,4)  NOT NULL,
    [Low] decimal(18,4)  NOT NULL,
    [Close] decimal(18,4)  NOT NULL,
    [WMAPeriod] decimal(18,4)  NOT NULL,
    [WMAValue] decimal(18,4)  NOT NULL
);
GO

-- Creating table 'Confirmations'
CREATE TABLE [dbo].[Confirmations] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Date] datetimeoffset  NOT NULL,
    [Signal] decimal(18,4)  NOT NULL,
    [CandleStickId] int  NOT NULL,
    [SetupId] int  NOT NULL
);
GO

-- Creating table 'Orders'
CREATE TABLE [dbo].[Orders] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Pair] nvarchar(50)  NOT NULL,
    [Type] nvarchar(50)  NOT NULL,
    [OrderType] nvarchar(50)  NOT NULL,
    [Price] decimal(18,4)  NULL,
    [Price2] decimal(18,4)  NULL,
    [Volume] decimal(18,4)  NOT NULL,
    [Leverage] nvarchar(50)  NULL,
    [Position] nvarchar(500)  NULL,
    [OFlags] nvarchar(500)  NULL,
    [Starttm] nvarchar(50)  NULL,
    [Expiretm] nvarchar(50)  NULL,
    [UserRef] nvarchar(100)  NULL,
    [Validate] bit  NOT NULL,
    [TxId] nvarchar(50)  NULL,
    [Status] nvarchar(50)  NULL,
    [Reason] nvarchar(100)  NULL,
    [OpenTime] nvarchar(50)  NULL,
    [CloseTime] nvarchar(50)  NULL,
    [VolumeExecuted] decimal(18,4)  NULL,
    [Cost] decimal(18,4)  NULL,
    [Fee] decimal(18,4)  NULL,
    [AveragePrice] decimal(18,4)  NULL,
    [StopPrice] decimal(18,4)  NULL,
    [LimitPrice] decimal(18,4)  NULL,
    [Info] nvarchar(500)  NULL,
    [Trades] nvarchar(500)  NULL,
    [CandleStickId] int  NULL,
    [ConfirmationId] int  NULL,
    [ConditionalCloseString] nvarchar(250)  NULL,
    [CreateDate] datetimeoffset  NULL
);
GO

-- Creating table 'Setups'
CREATE TABLE [dbo].[Setups] (
    [Id] int IDENTITY(1,1) NOT NULL,
    [Date] datetimeoffset  NOT NULL,
    [Type] int  NOT NULL,
    [Target] decimal(18,4)  NOT NULL,
    [CandleStickId] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Id] in table 'CandleSticks'
ALTER TABLE [dbo].[CandleSticks]
ADD CONSTRAINT [PK_CandleSticks]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Confirmations'
ALTER TABLE [dbo].[Confirmations]
ADD CONSTRAINT [PK_Confirmations]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Orders'
ALTER TABLE [dbo].[Orders]
ADD CONSTRAINT [PK_Orders]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- Creating primary key on [Id] in table 'Setups'
ALTER TABLE [dbo].[Setups]
ADD CONSTRAINT [PK_Setups]
    PRIMARY KEY CLUSTERED ([Id] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- Creating foreign key on [CandleStickId] in table 'Confirmations'
ALTER TABLE [dbo].[Confirmations]
ADD CONSTRAINT [FK_Confirmation_CandleStick]
    FOREIGN KEY ([CandleStickId])
    REFERENCES [dbo].[CandleSticks]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Confirmation_CandleStick'
CREATE INDEX [IX_FK_Confirmation_CandleStick]
ON [dbo].[Confirmations]
    ([CandleStickId]);
GO

-- Creating foreign key on [CandleStickId] in table 'Orders'
ALTER TABLE [dbo].[Orders]
ADD CONSTRAINT [FK_Order_CandleStick]
    FOREIGN KEY ([CandleStickId])
    REFERENCES [dbo].[CandleSticks]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Order_CandleStick'
CREATE INDEX [IX_FK_Order_CandleStick]
ON [dbo].[Orders]
    ([CandleStickId]);
GO

-- Creating foreign key on [CandleStickId] in table 'Setups'
ALTER TABLE [dbo].[Setups]
ADD CONSTRAINT [FK_Setup_CandleStick]
    FOREIGN KEY ([CandleStickId])
    REFERENCES [dbo].[CandleSticks]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Setup_CandleStick'
CREATE INDEX [IX_FK_Setup_CandleStick]
ON [dbo].[Setups]
    ([CandleStickId]);
GO

-- Creating foreign key on [ConfirmationId] in table 'Orders'
ALTER TABLE [dbo].[Orders]
ADD CONSTRAINT [FK_Confirmation_Confirmation]
    FOREIGN KEY ([ConfirmationId])
    REFERENCES [dbo].[Confirmations]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Confirmation_Confirmation'
CREATE INDEX [IX_FK_Confirmation_Confirmation]
ON [dbo].[Orders]
    ([ConfirmationId]);
GO

-- Creating foreign key on [SetupId] in table 'Confirmations'
ALTER TABLE [dbo].[Confirmations]
ADD CONSTRAINT [FK_Confirmation_Setup]
    FOREIGN KEY ([SetupId])
    REFERENCES [dbo].[Setups]
        ([Id])
    ON DELETE NO ACTION ON UPDATE NO ACTION;

-- Creating non-clustered index for FOREIGN KEY 'FK_Confirmation_Setup'
CREATE INDEX [IX_FK_Confirmation_Setup]
ON [dbo].[Confirmations]
    ([SetupId]);
GO

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------