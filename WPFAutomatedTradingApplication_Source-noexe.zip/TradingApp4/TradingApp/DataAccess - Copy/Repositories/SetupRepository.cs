﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess.Repositories
{
    public static class SetupRepository
    {
        public static void Save(Setup setup)
        {
            using (TradingAppDBEntities dc = new TradingAppDBEntities())
            {
                if (setup.Id > 0)
                {
                    Setup itemToUpdate = dc.Setups.Where(cs => cs.Id == setup.Id).FirstOrDefault();

                    if (itemToUpdate != null)
                    {
                        dc.Entry(itemToUpdate).CurrentValues.SetValues(setup);
                    }
                }
                else
                {
                    dc.Setups.Add(setup);
                }
                dc.SaveChanges();
            }
        }
    }
}
