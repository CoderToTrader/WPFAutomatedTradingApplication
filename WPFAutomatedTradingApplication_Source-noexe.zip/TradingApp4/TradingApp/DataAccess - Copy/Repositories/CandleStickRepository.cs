﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess.Repositories
{
    public static  class CandleStickRepository
    {
        public static void Save(CandleStick candleStick)
        {
            using (TradingAppDBEntities dc = new TradingAppDBEntities())
            {
                if (candleStick.Id > 0)
                {
                    CandleStick candleStickToToUpdate = dc.CandleSticks.Where(cs => cs.Id == candleStick.Id).FirstOrDefault();

                    if (candleStickToToUpdate != null)
                    {
                        dc.Entry(candleStickToToUpdate).CurrentValues.SetValues(candleStick);
                    }
                }
                else
                {
                    dc.CandleSticks.Add(candleStick);
                }
                dc.SaveChanges();
            }
        }
    }
}
