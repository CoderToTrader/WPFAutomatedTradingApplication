﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess.Repositories
{
    public static class OrderRepository
    {
        public static Order Save(Order order)
        {
         
            using (TradingAppDBEntities dc = new TradingAppDBEntities())
            {
                if (order.Id > 0)
                {
                    Order itemToUpdate = dc.Orders.Where(cs => cs.Id == order.Id).FirstOrDefault();

                    if (itemToUpdate != null)
                    {
                        dc.Entry(itemToUpdate).CurrentValues.SetValues(order);
                    }
                }
                else
                {
                    order = dc.Orders.Add(order);
                }
                dc.SaveChanges();
            }
            return order;
        }
    }
}
