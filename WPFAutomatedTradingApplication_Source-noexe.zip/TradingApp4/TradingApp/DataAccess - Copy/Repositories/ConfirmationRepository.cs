﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess.Repositories
{
    public static class ConfirmationRepository
    {
        public static void Save(Confirmation confirmation)
        {
            using (TradingAppDBEntities dc = new TradingAppDBEntities())
            {
                if (confirmation.Id > 0)
                {
                    Confirmation itemToUpdate = dc.Confirmations.Where(cs => cs.Id == confirmation.Id).FirstOrDefault();

                    if (itemToUpdate != null)
                    {
                        dc.Entry(itemToUpdate).CurrentValues.SetValues(confirmation);
                    }
                }
                else
                {
                    dc.Confirmations.Add(confirmation);
                }
                dc.SaveChanges();
            }
        }
    }
}
