﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess
{

    public enum SetupType
    {
        up = 1,
        down = 2,
    }

    public partial class Setup:INotifyPropertyChanged
    {
        public Setup(DateTimeOffset date, int type, decimal target)
        {
            Date = date;
            Type = type;
            Target = target;
        }

        public Setup(DateTimeOffset date, int type, decimal target, int candleStickId)
            : this(date, type, target)
        {
            CandleStickId = candleStickId;
        }

        public Confirmation Confirmation { get; set; }

        //for UI purposes
        bool isSelected;
        public bool IsSelected
        {
            get
            {
                return isSelected;
            }
            set
            {
                isSelected = value;
                OnPropertyChanged("IsSelected");
            }

        }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
