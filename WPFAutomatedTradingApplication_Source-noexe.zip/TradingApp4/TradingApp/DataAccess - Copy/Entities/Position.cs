﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess
{
    public class Position:INotifyPropertyChanged
    {
        public OrderType Direction { get; set; }
        public Order OpeningOrder { get; set; }
        public Order ClosingOrder { get; set; }
        public Order EmergencyExitOrder { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
