﻿using System;
namespace TradingApp.DataAccess
{
    public interface IOrderRepository
    {
        TradingApp.DataAccess.Order Save(TradingApp.DataAccess.Order order);
    }
}
