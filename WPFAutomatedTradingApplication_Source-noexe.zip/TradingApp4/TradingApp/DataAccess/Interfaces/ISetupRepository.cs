﻿using System;
namespace TradingApp.DataAccess
{
    public interface ISetupRepository
    {
        void Save(TradingApp.DataAccess.Setup setup);
    }
}
