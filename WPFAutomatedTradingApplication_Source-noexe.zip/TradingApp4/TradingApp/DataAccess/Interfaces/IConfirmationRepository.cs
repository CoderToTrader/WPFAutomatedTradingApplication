﻿using System;
namespace TradingApp.DataAccess
{
    public interface IConfirmationRepository
    {
        void Save(TradingApp.DataAccess.Confirmation confirmation);
    }
}
