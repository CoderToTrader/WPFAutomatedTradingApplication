﻿using System;
namespace TradingApp.DataAccess
{
    public interface ICandleStickRepository
    {
        void Save(TradingApp.DataAccess.CandleStick candleStick);
    }
}
