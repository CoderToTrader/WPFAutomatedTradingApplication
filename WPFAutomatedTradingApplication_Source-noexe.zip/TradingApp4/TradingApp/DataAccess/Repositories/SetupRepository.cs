﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess.Repositories
{
    [Export(typeof(ISetupRepository))]
    [ExportMetadata("Nature", "database")]
    public class SetupRepository : TradingApp.DataAccess.ISetupRepository
    {
        public void Save(Setup setup)
        {
            using (TradingAppDBEntities dc = new TradingAppDBEntities())
            {
                if (setup.Id > 0)
                {
                    Setup itemToUpdate = dc.Setups.Where(cs => cs.Id == setup.Id).FirstOrDefault();

                    if (itemToUpdate != null)
                    {
                        dc.Entry(itemToUpdate).CurrentValues.SetValues(setup);
                    }
                }
                else
                {
                    dc.Setups.Add(setup);
                }
                dc.SaveChanges();
            }
        }
    }
}
