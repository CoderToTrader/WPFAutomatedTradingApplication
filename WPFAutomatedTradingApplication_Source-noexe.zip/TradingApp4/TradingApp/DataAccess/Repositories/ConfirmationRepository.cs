﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradingApp.DataAccess.Repositories
{
    [Export(typeof(IConfirmationRepository))]
    [ExportMetadata("Nature", "database")]
    public class ConfirmationRepository : TradingApp.DataAccess.IConfirmationRepository
    {
        public void Save(Confirmation confirmation)
        {
            using (TradingAppDBEntities dc = new TradingAppDBEntities())
            {
                if (confirmation.Id > 0)
                {
                    Confirmation itemToUpdate = dc.Confirmations.Where(cs => cs.Id == confirmation.Id).FirstOrDefault();

                    if (itemToUpdate != null)
                    {
                        dc.Entry(itemToUpdate).CurrentValues.SetValues(confirmation);
                    }
                }
                else
                {
                    dc.Confirmations.Add(confirmation);
                }
                dc.SaveChanges();
            }
        }
    }
}
